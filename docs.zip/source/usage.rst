Usage
=====

Here's how you can use AttentionMe to process an image:

.. code-block:: python

   from attentionme.segmentation import segment_people
   from attentionme.remove_background import remove_background

   # Load an image
   input_file = "example.jpg"
   segmented_image = segment_people(input_file)
   final_image = remove_background(segmented_image)

   final_image.save("output.jpg")