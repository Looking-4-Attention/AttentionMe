.. AttentionMe documentation master file, created by
   sphinx-quickstart on Sun Dec  8 14:34:42 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

AttentionMe Documentation
=========================

Welcome to AttentionMe's documentation! This library provides tools for video and image processing.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   installation
   usage
   modules
   contributing
   license

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
