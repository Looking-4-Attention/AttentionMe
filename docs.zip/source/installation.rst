Installation
============

You can install AttentionMe from PyPI:

.. code-block:: bash

   pip install attentionme