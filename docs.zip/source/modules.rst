Modules Overview
================

- `segmentation.py`: Functions to identify and segment people.
- `remove_background.py`: Removes backgrounds for a clean subject focus.
- `zoom_in.py`: Automatic zoom-in on key areas.
- `adjust_brightness.py`: Adjust image brightness.
- `pointing.py`: Highlights specific points or regions.
- `crop.py`: Crops images to desired focus points or dimensions.
- `enlargement.py`: Enhances specific parts of images.